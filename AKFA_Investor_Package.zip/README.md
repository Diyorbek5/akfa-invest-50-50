# AKFA Dilerlik Biznesi — Investor Prezentatsiyasi

## Ishga tushirish

### Brauzerda ochish
1. `akfa-investor-presentation.html` faylini istalgan zamonaviy brauzerda oching
2. Chrome, Firefox, Edge yoki Safari tavsiya etiladi

### Navigatsiya
- **Strelka tugmalari** (← →): Slaydlar orasida harakatlanish
- **Space**: Keyingi slayd
- **Home / End**: Birinchi yoki oxirgi slaydga o'tish
- **F**: To'liq ekran rejimi
- **Sensorli ekran**: Chapga/o'ngga suring
- **Mouse wheel**: Yuqoriga/pastga aylantirish

### Fayl tuzilmasi
```
akfa invest/
├── akfa-investor-presentation.html  — Asosiy prezentatsiya
├── investor-data-validation.md      — Tekshirilishi kerak ma'lumotlar
├── image-sources.md                 — Rasmlar manbalari
├── README.md                        — Ushbu fayl
└── assets/
    ├── hero-bg.jpg                  — Bosh sahifa fon rasmi
    ├── warehouse.jpg                — Ombor/logistika rasmi
    └── construction.jpg             — Qurilish/shahar rasmi
```

### Texnik talablar
- Zamonaviy brauzer (ES6+ qo'llab-quvvatlashi)
- Internet ulanishi (Google Fonts va GSAP CDN uchun)
- Minimal ekran o'lchami: 1024×768 tavsiya etiladi

### Ma'lumotlar manbasi
- Excel fayl: "акфа презинтатцыя — копия.xlsx"
- 6 ta varaq: kompaniya ma'lumotlari, 2023/2024/2025 moliyaviy natijalar, investor taklifi, mablag'lar taqsimoti
- Valyuta: O'zbekiston so'mi (UZS) va AQSh dollari ($)
